import { useState } from "react";

const FormComponent = ({ onAdd }: { onAdd: (user: { name: string; email: string }) => void }) => {
  const [input, setInput] = useState({ name: "", email: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.name && input.email) {
      onAdd(input);
      setInput({ name: "", email: "" });
    }
  };

  return (
    <form className="space-y-4" onSubmit={handleSubmit}>
      <input
        type="text"
        placeholder="Enter Name"
        className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
        value={input.name}
        onChange={(e) => setInput({ ...input, name: e.target.value })}
      />
      <input
        type="email"
        placeholder="Enter Email"
        className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
        value={input.email}
        onChange={(e) => setInput({ ...input, email: e.target.value })}
      />
      <button
        type="submit"
        className="w-full bg-green-500 text-white px-6 py-3 rounded-lg shadow-md hover:bg-green-600 transition-all duration-300"
      >
        Add User
      </button>
    </form>
  );
};

export default FormComponent;
