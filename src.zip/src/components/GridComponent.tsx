import React from "react";

interface User {
  id: number;
  name: string;
  email: string;
}

interface GridComponentProps {
  data: User[];
}

const GridComponent: React.FC<GridComponentProps> = ({ data }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
      {data.map((item) => (
        <div
          key={item.id}
          className="p-6 bg-white rounded-lg shadow-md border border-gray-200 transform hover:scale-105 transition-all duration-300"
        >
          <h3 className="text-xl font-semibold text-blue-600">{item.name}</h3>
          <p className="text-gray-700">{item.email}</p>
        </div>
      ))}
    </div>
  );
};

export default GridComponent;
