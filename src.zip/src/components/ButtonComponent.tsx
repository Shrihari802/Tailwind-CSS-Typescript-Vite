const ButtonComponent = ({ text, onClick }: { text: string; onClick: () => void }) => {
  return (
    <button
      className="bg-gradient-to-r from-green-400 to-blue-500 text-white px-6 py-2 rounded-lg shadow-md hover:from-blue-500 hover:to-green-400 transition-all duration-300 transform hover:scale-105"
      onClick={onClick}
    >
      {text}
    </button>
  );
};

export default ButtonComponent;
