// /data/sampleData.ts

export interface User {
  id: number;
  name: string;
  email: string;
}

export const sampleData: User[] = [
  { id: 1, name: "Shrihari", email: "shri@gmail.com" },
  { id: 2, name: "Shrinu", email: "shrinu@gmail.com" },
  { id: 3, name: "Jyothi", email: "jyothi@gmail.com" }
];
