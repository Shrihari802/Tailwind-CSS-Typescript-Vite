import { useState } from "react";
import ButtonComponent from "./components/ButtonComponent";
import FormComponent from "./components/FormComponent";
import GridComponent from "./components/GridComponent";
import { sampleData } from "./data/sampleData";

export default function App() {
  const [users, setUsers] = useState(sampleData);

  const addUser = (user: { name: string; email: string }) => {
    setUsers([...users, { id: users.length + 1, ...user }]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-r from-blue-500 to-purple-600 flex flex-col items-center justify-center p-6">
      <div className="bg-white shadow-xl rounded-lg p-8 w-full max-w-3xl">
        <h1 className="text-3xl font-bold text-center text-gray-800 mb-6">🚀 Welcome to Vite + Tailwind CSS</h1>
        
        <div className="flex justify-center mb-6">
          <ButtonComponent text="Click Me" onClick={() => alert("Button Clicked!")} />
        </div>
        
        <div className="bg-gray-100 p-6 rounded-lg shadow-md mb-6">
          <FormComponent onAdd={addUser} />
        </div>
        
        <div className="mt-6">
          <GridComponent data={users} />
        </div>
      </div>
    </div>
  );
}
